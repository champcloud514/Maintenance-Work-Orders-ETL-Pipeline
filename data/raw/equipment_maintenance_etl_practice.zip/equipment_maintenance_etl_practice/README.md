# Equipment Maintenance ETL Practice Project

## Scenario
You are a junior data engineer supporting an offshore operations team. The maintenance department exports work-order data and an equipment master list as CSV files. Build an ETL pipeline in Python and load clean data into Snowflake.

## Files
- `data/raw/maintenance_work_orders.csv`: work-order transactions (5,010 rows including 10 exact duplicate rows).
- `data/raw/equipment_master.csv`: equipment reference data (80 rows).

## Business objective
Create a reliable, auditable dataset for maintenance KPI reporting by equipment, field, work type and priority.

## Required pipeline
Implement three scripts:
1. `scripts/extract.py`
2. `scripts/transform.py`
3. `scripts/load.py`

Use functions, `pathlib`, logging, pandas, environment variables (`python-dotenv`) and the Snowflake Python connector.

## Extraction requirements
- Read both CSV files from `data/raw/`.
- Check that files exist and are not empty.
- Log source row counts.
- Do not modify raw source files.

## Transformation and data-quality requirements
- Standardize column names to lowercase snake_case.
- Trim whitespace from text fields; standardize category casing consistently.
- Convert date columns to datetime and numeric columns to numeric types.
- Remove exact duplicate rows.
- Enforce unique `work_order_id`. For repeated IDs, keep one deterministic record (document your rule) and send other rows to rejected data.
- Reject rows with missing `work_order_id`, `equipment_id`, or `reported_date`.
- Reject rows whose `equipment_id` does not exist in the equipment master.
- Reject negative `labor_hours`, `parts_cost_usd`, or `downtime_hours`.
- Reject `reported_date` later than the current processing date.
- Validate `priority` against P1, P2, P3, P4.
- For completed/closed work orders, investigate missing `completed_date`; either reject or apply a documented rule. Do not silently invent dates.
- Do not automatically replace missing labor hours with zero or a median. Decide and document whether to reject or retain as null.
- Add `rejection_reason` to rejected rows. A row can have more than one reason.
- Save:
  - `data/processed/clean_work_orders.csv`
  - `data/processed/rejected_work_orders.csv`
  - `data/processed/clean_equipment_master.csv`

## Snowflake requirements
Create:
- Database: `OIL_GAS_DB` (reuse existing database)
- Schema: `MAINTENANCE`
- Warehouse: `COMPUTE_WH` (reuse existing warehouse)
- Tables: `EQUIPMENT_MASTER`, `MAINTENANCE_WORK_ORDERS`
- Internal stage: `MAINTENANCE_STAGE`
- CSV file formats appropriate for the two CSV files.

Load the clean equipment master and clean work orders into their respective Snowflake tables. Use `PUT` from Python to upload the files and `COPY INTO` to load them. Do not load rejected rows into the production tables.

## SQL verification and KPI queries
Write SQL to verify:
1. Total work orders loaded.
2. Work orders by status and priority.
3. Total downtime hours by field and equipment type (join work orders to equipment master).
4. Average repair labor hours by work type.
5. Top 10 equipment items by total downtime.
6. Count of rejected rows and common rejection reasons (from the rejected CSV locally, or optionally a separate Snowflake reject table).

## Engineering expectations
- Use clear function boundaries: `extract_data`, `transform_data`, `validate_data`, `load_data`.
- Handle exceptions and close Snowflake connections/cursors reliably.
- Use parameterized/validated configuration where practical.
- Make the load repeatable: consider Snowflake COPY file-load history and avoid blindly using `FORCE=TRUE`.
- Keep credentials in `.env`; add `.env` to `.gitignore`.
- Include a short README describing assumptions and data-quality decisions.

## Suggested project structure
```text
equipment-maintenance-etl/
  data/
    raw/
    processed/
  scripts/
    extract.py
    transform.py
    load.py
  sql/
    create_objects.sql
    analytics.sql
  logs/
  tests/
  .env                 # never commit
  .gitignore
  README.md
```

## Suggested practice sequence for today
1. Inspect both raw CSV files and their schemas.
2. Build extraction functions and run them.
3. Implement transformation and validation rules.
4. Save clean and rejected outputs.
5. Create Snowflake objects.
6. Implement Python PUT + COPY INTO loading.
7. Run KPI SQL and compare counts with local outputs.

## Important
This is synthetic training data. The values are designed for ETL practice, not operational decisions. Treat the rejection rules as project requirements, but document any reasonable interpretation you make.
